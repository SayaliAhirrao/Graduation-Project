


<html>
<head>
    <title>eHealth Monitoring System</title>
    <link rel="shortcut icon" type="image/x-icon" href="images/icon1.png" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="jquery-3.5.1.min.js"></script>





    </head>
</html>